# src/grayscale.py
from PIL import Image
import numpy as np
import os

# ----------------------
# BASIC IMAGE FUNCTIONS
# ----------------------

def load_image(path):
    """Load image -> numpy array float32"""
    img = Image.open(path).convert('RGB')
    return np.array(img).astype('float32')

def save_image(arr, path):
    """Save numpy array -> image"""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    Image.fromarray(arr.astype('uint8')).save(path)


# ----------------------
# GRAYSCALE METHODS
# ----------------------

def gray_average(rgb):
    r, g, b = rgb[:,:,0], rgb[:,:,1], rgb[:,:,2]
    gray = (r + g + b) / 3
    return np.stack([gray, gray, gray], axis=2)

def gray_luminosity(rgb):
    r, g, b = rgb[:,:,0], rgb[:,:,1], rgb[:,:,2]
    gray = 0.3*r + 0.59*g + 0.11*b
    return np.stack([gray, gray, gray], axis=2)

def gray_desaturation(rgb):
    mx = rgb.max(axis=2)
    mn = rgb.min(axis=2)
    gray = (mx + mn) / 2
    return np.stack([gray, gray, gray], axis=2)

def gray_decomposition_max(rgb):
    gray = rgb.max(axis=2)
    return np.stack([gray, gray, gray], axis=2)

def gray_decomposition_min(rgb):
    gray = rgb.min(axis=2)
    return np.stack([gray, gray, gray], axis=2)

def gray_channel(rgb, channel='r'):
    c = channel.lower()
    if c == 'r':
        gray = rgb[:,:,0]
    elif c == 'g':
        gray = rgb[:,:,1]
    elif c == 'b':
        gray = rgb[:,:,2]
    else:
        raise ValueError("Channel must be 'r','g', or 'b'")
    return np.stack([gray, gray, gray], axis=2)


# ----------------------
# QUANTIZATION + DITHERING
# ----------------------

def quantize_gray_single(gray_single, n_shades):
    """
    Quantize a single-channel float array (0..255) into n_shades discrete levels.
    Returns float array with quantized values (still 0..255).
    """
    if not (2 <= n_shades <= 256):
        raise ValueError("n_shades must be between 2 and 256")
    factor = 255.0 / (n_shades - 1)
    q = np.round(gray_single / factor) * factor
    return q

def floyd_steinberg_dither(gray_single, n_shades):
    """
    Apply Floyd-Steinberg error diffusion to a 2D float gray image (0..255).
    Returns dithered float array (0..255).
    """
    h, w = gray_single.shape
    img = gray_single.astype(np.float32).copy()
    factor = 255.0 / (n_shades - 1)

    for y in range(h):
        for x in range(w):
            old = img[y, x]
            new = np.round(old / factor) * factor
            img[y, x] = new
            err = old - new
            if x + 1 < w:
                img[y, x+1] += err * 7/16
            if x - 1 >= 0 and y + 1 < h:
                img[y+1, x-1] += err * 3/16
            if y + 1 < h:
                img[y+1, x] += err * 5/16
            if x + 1 < w and y + 1 < h:
                img[y+1, x+1] += err * 1/16

    return np.clip(img, 0, 255)

def quantized_image_from_rgb(rgb, n_shades, base_method='luminosity'):
    """
    Return a 3-channel quantized image (no dither). base_method: 'luminosity' or 'average'
    """
    if base_method == 'luminosity':
        gray3 = gray_luminosity(rgb)
    elif base_method == 'average':
        gray3 = gray_average(rgb)
    else:
        raise ValueError("base_method must be 'luminosity' or 'average'")
    gray_single = gray3[:,:,0]
    q = quantize_gray_single(gray_single, n_shades)
    return np.stack([q, q, q], axis=2)

def dithered_image_from_rgb(rgb, n_shades, base_method='luminosity'):
    """
    Return a 3-channel dithered image using Floyd-Steinberg.
    """
    if base_method == 'luminosity':
        gray3 = gray_luminosity(rgb)
    elif base_method == 'average':
        gray3 = gray_average(rgb)
    else:
        raise ValueError("base_method must be 'luminosity' or 'average'")
    gray_single = gray3[:,:,0]
    d = floyd_steinberg_dither(gray_single, n_shades)
    return np.stack([d, d, d], axis=2)
