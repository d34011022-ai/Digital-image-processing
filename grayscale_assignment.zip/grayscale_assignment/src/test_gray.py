from PIL import Image
import numpy as np
import os

inp = "images/input.jpg"
  # Make sure images/input.jpg exists
out = "../outputs/avg.jpg"
os.makedirs(os.path.dirname(out), exist_ok=True)

img = Image.open(inp).convert('RGB')
arr = np.array(img).astype('float32')

# average grayscale conversion
r, g, b = arr[:,:,0], arr[:,:,1], arr[:,:,2]
gray = ((r + g + b) / 3.0).astype('uint8')
gray3 = np.stack([gray, gray, gray], axis=2)

Image.fromarray(gray3).save(out)
print("Saved grayscale image:", out)
