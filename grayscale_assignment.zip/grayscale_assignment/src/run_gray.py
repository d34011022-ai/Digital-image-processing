# src/run_gray.py
from grayscale import (
    load_image, save_image,
    gray_average, gray_luminosity, gray_desaturation,
    gray_decomposition_max, gray_decomposition_min,
    gray_channel,
    quantized_image_from_rgb, dithered_image_from_rgb
)

# Load input
img = load_image("images/input.jpg")

# Basic method outputs (1-6)
save_image(gray_average(img), "outputs/avg_method.jpg")
save_image(gray_luminosity(img), "outputs/luminosity_method.jpg")
save_image(gray_desaturation(img), "outputs/desaturation_method.jpg")
save_image(gray_decomposition_max(img), "outputs/decomposition_max.jpg")
save_image(gray_decomposition_min(img), "outputs/decomposition_min.jpg")
save_image(gray_channel(img, 'r'), "outputs/channel_red.jpg")
save_image(gray_channel(img, 'g'), "outputs/channel_green.jpg")
save_image(gray_channel(img, 'b'), "outputs/channel_blue.jpg")

# ---- Quantization examples ----
# Quantize to 4 shades (no dither)
save_image(quantized_image_from_rgb(img, 4, base_method='luminosity'),
           "outputs/quant_4_no_dither.jpg")

# Quantize to 8 shades (no dither)
save_image(quantized_image_from_rgb(img, 8, base_method='luminosity'),
           "outputs/quant_8_no_dither.jpg")

# ---- Dithered examples ----
# Dither to 4 shades
save_image(dithered_image_from_rgb(img, 4, base_method='luminosity'),
           "outputs/dither_4.jpg")

# Dither to 8 shades
save_image(dithered_image_from_rgb(img, 8, base_method='luminosity'),
           "outputs/dither_8.jpg")

print("Saved quantized/dithered outputs:")
print(" - outputs/quant_4_no_dither.jpg")
print(" - outputs/quant_8_no_dither.jpg")
print(" - outputs/dither_4.jpg")
print(" - outputs/dither_8.jpg")
